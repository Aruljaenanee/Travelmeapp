package com.example.travelme;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Landingpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landingpage); // Check if the layout resource is correctly referenced here
        // ...
        Button nextButton = findViewById(R.id.buttonNext);
        nextButton.setOnClickListener(view -> {
            // Handle button click event
            Intent intent = new Intent(Landingpage.this, LoginPage.class);
            startActivity(intent);
        });
    }
}