package com.example.travelme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DetailPage extends AppCompatActivity {

    private FirebaseFirestore firestore;
    private int cid;
    private ArrayList<Integer> addToCart = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_page);

        cid = getIntent().getIntExtra("cid", 0);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();

        CollectionReference placesRef = db.collection("Products");

        Query query = placesRef.whereEqualTo("ID", cid);

        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                QuerySnapshot querySnapshot = task.getResult();
                if (querySnapshot != null && !querySnapshot.isEmpty()) {
                    DocumentSnapshot documentSnapshot = querySnapshot.getDocuments().get(0);
                    // Handle the document snapshot
                    // For example, you can access field values using documentSnapshot.getString("fieldName")

                    // Retrieve the field values from the document snapshot
                    String name = documentSnapshot.getString("Name");
                    String description = documentSnapshot.getString("Detail");
                    Long priceValue = documentSnapshot.getLong("Price");
                    String imageUrl = documentSnapshot.getString("imageUrl");


                    // Bind the retrieved data to TextViews
                    TextView nameTextView = findViewById(R.id.textView13);
                    TextView descriptionTextView = findViewById(R.id.textView20);
                    TextView priceTextView = findViewById(R.id.textView14);
                    ImageView imagee = findViewById(R.id.imageView7);

                    nameTextView.setText(name);
                    descriptionTextView.setText(description);
                    int priceInt = priceValue.intValue();
                    priceTextView.setText(String.valueOf(priceInt));
                    Glide.with(DetailPage.this)
                            .load(imageUrl)
                            .into(imagee);



                } else {
                    // No document found with the given placeID
                }
            } else {
                // An error occurred while fetching the document
                Exception exception = task.getException();
                // Handle the error
            }
        });

        ImageView imageView = findViewById(R.id.imageView4);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the cid value
                int cidValue = cid; // Replace with your actual method to get the cid value

                // Create a new document in the "wishlist" collection with the cid value as the document ID
                DocumentReference wishlistRef = firestore.collection("wishlist").document(String.valueOf(cidValue));

                // Create a data object with the cid value
                Map<String, Object> data = new HashMap<>();
                data.put("ID", cidValue);

                // Save the data to the "wishlist" document
                wishlistRef.set(data)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                // Handle the successful write operation
                                Toast.makeText(getApplicationContext(), "Item added to Wishlist", Toast.LENGTH_SHORT).show();

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // Handle the failure of the write operation
                            }
                        });
            }
        });

        ImageView imageViewBack = findViewById(R.id.imageView3);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to navigate back to the home page
                Intent intent = new Intent(DetailPage.this, HomePage.class);
                startActivity(intent);
                finish(); // Optional: Finish the current activity
            }
        });

        Button addToCartButton = findViewById(R.id.addtocart);
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the cid value
                int cidValue = cid; // Replace with your actual method to get the cid value

                // Add the cid to the addToCart array using CartManager
                CartManager.getInstance().addToCart(cidValue);

                // Display a Toast message
                Toast.makeText(getApplicationContext(), "Item added to Cart", Toast.LENGTH_SHORT).show();
            }
        });




    }
}