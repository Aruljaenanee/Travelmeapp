package com.example.travelme;

import java.util.ArrayList;
import java.util.List;

public class CartManager {
    private static CartManager instance;
    private ArrayList<Integer> addToCart;

    private List<Integer> cartItems;

    private CartManager() {
        addToCart = new ArrayList<>();
    }

    public static CartManager getInstance() {
        if (instance == null) {
            synchronized (CartManager.class) {
                if (instance == null) {
                    instance = new CartManager();
                }
            }
        }
        return instance;
    }

    public ArrayList<Integer> getAddToCart() {
        return addToCart;
    }

    public void addToCart(int cid) {
        addToCart.add(cid);
    }

    public void removeFromCart(int cid) {
        addToCart.remove(Integer.valueOf(cid));
    }

    public void clearCart() {
        addToCart.clear();
    }

    public List<Integer> getCartItems() {
        return new ArrayList<>(addToCart);
    }

}
