package com.example.travelme;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class History extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        ImageView imageViewBack = findViewById(R.id.imageView5);

        Button startExploringButton = findViewById(R.id.button3);
        startExploringButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to navigate to the home page
                Intent intent = new Intent(History.this, HomePage.class);
                startActivity(intent);
                finish(); // Optional: Finish the current activity
            }
        });

        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to navigate back to the home page
                Intent intent = new Intent(History.this, HomePage.class);
                startActivity(intent);
                finish(); // Optional: Finish the current activity
            }
        });
    }
}