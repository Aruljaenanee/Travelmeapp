package com.example.travelme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.ImageView;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.List;


public class HomePage extends AppCompatActivity {

    private EditText myEditText;

    private LinearLayout parentLayout;
    private FirebaseFirestore firestore;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);


        myEditText = findViewById(R.id.editTextText);
        ImageView cart = findViewById(R.id.imageView12);
        ImageView heartt = findViewById(R.id.imageViewHeart);
        ImageView timer = findViewById(R.id.imageViewTimer);
        ImageView user = findViewById(R.id.imageViewUser);

        firestore = FirebaseFirestore.getInstance();

        // Get a reference to the parent layout
        parentLayout = findViewById(R.id.category_layout);

        firestore.collection("Products")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String Name = document.getString("Name");
                                String imageUrl = document.getString("imageUrl");
                                Integer cid = Math.toIntExact(document.getLong("ID"));

                                // Create a component view
                                View componentView = LayoutInflater.from(HomePage.this).inflate(R.layout.home_component, parentLayout, false);

                                CardView card = componentView.findViewById(R.id.cardView1);
                                ImageView imageView = componentView.findViewById(R.id.imageView20);
                                TextView text = componentView.findViewById(R.id.textView31);

                                text.setText(Name);
                                Glide.with(HomePage.this)
                                        .load(imageUrl)
                                        .into(imageView);


                                // Set click listener for the button
                                card.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        // Start the new activity here
                                        Intent intent = new Intent(HomePage.this, DetailPage.class);
                                        intent.putExtra("cid", cid); // Pass the cid as an extra
                                        startActivity(intent);
                                    }
                                });

                                parentLayout.addView(componentView);
                            }
                        } else {
                            // Handle error
                        }
                    }
                });






        myEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE || event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    Intent intent = new Intent(HomePage.this, searchResults.class);
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });



        heartt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click event
                Intent intent = new Intent(HomePage.this, WishList.class);
                startActivity(intent);
            }
        });

        timer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click event
                Intent intent = new Intent(HomePage.this, History.class);
                startActivity(intent);
            }
        });

        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click event
                Intent intent = new Intent(HomePage.this, ProfilePage.class);
                startActivity(intent);
            }
        });

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click event
                Intent intent = new Intent(HomePage.this, CartPage.class);
                startActivity(intent);
            }
        });

    }
    private void redirectToDetailPage() {
        // Logic to redirect to another page
        Intent intent = new Intent(HomePage.this, DetailPage.class);
        startActivity(intent);
    }



}