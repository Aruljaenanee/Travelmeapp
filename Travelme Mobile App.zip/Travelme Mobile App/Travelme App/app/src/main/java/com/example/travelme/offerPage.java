package com.example.travelme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class offerPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offer_page);
        ImageView imageViewBack = findViewById(R.id.imageView10);

        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to navigate back to the home page
                Intent intent = new Intent(offerPage.this, HomePage.class);
                startActivity(intent);
                finish(); // Optional: Finish the current activity
            }
        });
    }
}