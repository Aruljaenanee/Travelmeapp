package com.example.travelme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;


public class CartPage extends AppCompatActivity {

    private FirebaseFirestore firestore;

    private LinearLayout parentLayout;
    private CartManager cartManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_page);

        firestore = FirebaseFirestore.getInstance();
        cartManager = CartManager.getInstance();
        parentLayout = findViewById(R.id.linearLayout);

        ArrayList<Integer> addToCart = CartManager.getInstance().getAddToCart();

// Check if the array is empty
        if (addToCart.isEmpty()) {
            Log.d("Array Data", "The addToCart array is empty.");
        } else {
            // Print the contents of the array
            Log.d("Array Data", "addToCart array contains: " + addToCart.toString());
        }


        CollectionReference productsRef = firestore.collection("Products");

        Query query = productsRef.whereIn("ID", cartManager.getCartItems());

        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    QuerySnapshot querySnapshot = task.getResult();
                    if (querySnapshot != null && !querySnapshot.isEmpty()) {
                        List<DocumentSnapshot> documents = querySnapshot.getDocuments();
                        // Handle the document snapshots here
                        for (DocumentSnapshot document : documents) {
                            // Retrieve the field values from the document
                            String name = document.getString("Name");
                            Long priceValue = document.getLong("Price");
                            String imageUrl = document.getString("imageUrl");



                            View componentView = LayoutInflater.from(CartPage.this).inflate(R.layout.wish_component, parentLayout, false);

                            CardView card = componentView.findViewById(R.id.cardView1);
                            //ImageView imageView = componentView.findViewById(R.id.imageView20);
                            TextView text = componentView.findViewById(R.id.textView11);
                            TextView price = componentView.findViewById(R.id.textView13);
                            ImageView image = componentView.findViewById(R.id.imageView10);

                            text.setText(name);
                            int priceInt = priceValue.intValue();
                            price.setText(String.valueOf(priceInt));
                            Glide.with(CartPage.this)
                                    .load(imageUrl)
                                    .into(image);

                            parentLayout.addView(componentView);

                            // Create components for each document
                        }
                    } else {
                        Log.d("Firestore Data", "No documents found");
                        // No documents found
                    }
                } else {
                    // An error occurred while fetching the documents
                    Exception exception = task.getException();
                    Log.e("Firestore Error", "Error retrieving documents", exception);
                    // Handle the error
                }
            }
        });





        ImageView backButton = findViewById(R.id.imageView3);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        Button orderButton = findViewById(R.id.button5);
        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(CartPage.this, checkout.class);
                startActivity(intent);
            }
        });







    }
}