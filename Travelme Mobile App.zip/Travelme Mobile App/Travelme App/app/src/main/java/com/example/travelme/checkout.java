package com.example.travelme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class checkout extends AppCompatActivity {
    private EditText nameEditText, addressEditText, numberEditText;
    private CartManager cartManager;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        nameEditText = findViewById(R.id.txtname);
        addressEditText = findViewById(R.id.txtaddress);
        numberEditText = findViewById(R.id.txtnumber);

        cartManager = CartManager.getInstance();
        firestore = FirebaseFirestore.getInstance();

        Button orderButton = findViewById(R.id.button3); // Replace with your button's ID
        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                String address = addressEditText.getText().toString();
                String number = numberEditText.getText().toString();

                ArrayList<Integer> productIds = cartManager.getAddToCart();
                saveOrderData(name, address, number, productIds);
            }
        });
    }

    private void saveOrderData(String name, String address, String number, ArrayList<Integer> productIds) {
        CollectionReference ordersRef = firestore.collection("orders");

        Map<String, Object> orderData = new HashMap<>();
        orderData.put("name", name);
        orderData.put("address", address);
        orderData.put("number", number);
        orderData.put("products", productIds);

        ordersRef.add(orderData)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        // Order data saved successfully
                        Toast.makeText(checkout.this, "Order placed successfully!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Failed to save order data
                        Toast.makeText(checkout.this, "Failed to place order. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                });
    }


}